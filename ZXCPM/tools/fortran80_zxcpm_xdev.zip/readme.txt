cpm f80.cpm OTHELLO=OTHELLO   
cpm l80zx.cpm OTHELLO,OTHELLO /n/e      
cpmrm -f quorum disk.trd 0:OTHELLO.CM6
cpmcp -f quorum disk.trd othello.cm6 0:OTHELLO.CM6

# ZX Quorum 128
diskdef quorum
  seclen 1024
  cylinders 80
  sectrk 5
  heads 2
  blocksize 2048
  maxdir 128
  boottrk 4
  os 2.2
end
