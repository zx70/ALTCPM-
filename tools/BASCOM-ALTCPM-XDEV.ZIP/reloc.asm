
; Convert "program.com" to a hypotetical CP/M system
; with TPA at 1100h to a standard CP/M program

; "program.com" needs to be linked with a custom version of link-80

; z88dk-z80asm -b reloc.asm
; rebase.exe pgm_0100 pgm_4300 pgm_1100 4096
; copy /b reloc.bin+program.com newprog.com

org 100h
top:
	ld hl,0
	ld de,$1000
	ld bc,$100
	ldir
	jp 1100h
bottom:
	defs 1000h-bottom


