This kit requires a command line CP/M emulator (e.g. CPM.EXE) and the z88dk/support/rel/rebase.c program.
The .bat files should be easy to convert to shell commands if you are a Linux user.

Usage:


To build PROGRAM.BAS for ZXCPM (-> PROGRAM.CM6):
---------------------------------------------------
copy shift\baslib.rel . /y
cpm bascom.cpm %1=%1
cpm l80shift.cpm %1,%1 /n/e
ren %1.com %1.shift
copy straight\baslib.rel . /y
cpm bascom.cpm %1=%1
cpm l80straight.cpm %1,%1 /n/e
ren %1.com %1.straight
rebase %1.straight %1.shift %1.cm6 24576



To build PROGRAM.BAS for ALTCPM (-> PROGRAM.COM on ALTCPM for Zenith H89 or TRS 80 Model I):
---------------------------------------------------
copy shift\baslib.rel . /y
cpm bascom.cpm %1=%1
cpm l80shift.cpm %1,%1 /n/e
ren %1.com %1.shift
copy straight\baslib.rel . /y
cpm bascom.cpm %1=%1
cpm l80straight.cpm %1,%1 /n/e
ren %1.com %1.straight
rebase %1.straight %1.shift %1.com 16896

