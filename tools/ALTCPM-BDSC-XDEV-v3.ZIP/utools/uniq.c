/*  uniq.c -- UTOOL. Filters out adjacent duplicate lines
          in sorted file.  Lines must be identical
          (including same length) to be filtered out.

     author: David H. Wolen
     last change: 12/2/82

     option:  -c  prefixes each output line with count
     usage:  sort <infile |uniq >outfile -c

     input:    STDIN
     output:   STDOUT

     linkage: a:clink uniq -f dio -ca (uses deff3.crl)
*/

#include "a:bdscio.h"
#include "dio.h"
#define  STDIN   0
#define  STDOUT  1
#define  STDERR  4

main(argc,argv)
int  argc;
char *argv[];
{
     int  count, cflag;
     char *s, line1[MAXLINE], line2[MAXLINE];

     dioinit(&argc, argv);
     cflag=FALSE;

     while( --argc>0 && (*++argv)[0]=='-')
          for(s=argv[0]+1; *s != '\0'; s++)
               switch(*s)
                    {case 'C':  cflag=TRUE; break;
                    default:    error("uniq: -c is only valid option");
                    }

     if(!fgets(line1,STDIN))  error("uniq: empty input file");

     count=1;

     while(fgets(line2,STDIN))
          if(eqs(line1,line2))  count++;
          else
               {if(cflag)  fprintf(STDOUT,"%d %s",count,line1);
               else        fputs(line1,STDOUT);
               strcpy(line1,line2);
               count=1;
               }

     if(cflag)  fprintf(STDOUT,"%d %s",count,line1);
     else       fputs(line1,STDOUT);

     dioflush();
}
