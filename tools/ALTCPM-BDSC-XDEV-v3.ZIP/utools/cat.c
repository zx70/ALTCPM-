/*  cat.c -- UTOOL. Concatenate files ver 2.  
     author: David H. Wolen
     last change: 6/12/83

     usage:
          (1) copy console input to file (^z<cr> to stop)
               cat >ofile
          (2) concat inp files and write on output file
               cat ifile1 ifile2 >ofile
          (3) concat input files and pass to std input of prog2
               cat ifile1 ifile2 |prog2
          (4) clean up WordStar doc file
               cat -w file.doc >ofile
 
     option:   -w  clean up WordStar doc files by zeroing
                    hi bits and converting strange characters
                    to blanks

     input:    files or STDIN
     output:   STDOUT


     linkage: a:clink cat -f dio -ca
*/

#include "a:bdscio.h"
#include "a:dio.h"
#define STDERR  4

main(argc,argv)
int  argc;
char *argv[];
{
     char ibuf[BUFSIZ], undoc(), *s;
     int  c, isstdin, wsflg;

     dioinit(&argc,argv);
     wsflg=FALSE;

     while(--argc > 0 && (*++argv)[0] == '-')
          for(s=argv[0]+1; *s != '\0'; s++)
               switch(*s)
                    {case 'W':  wsflg=TRUE; break;
                    default:  fprintf(STDERR,"cat: invalid option\n");
                              exit(dioflush());
                    }

     if(argc <= 0)
          isstdin=TRUE;
     else
          isstdin=FALSE;

     if(isstdin)         /* std input */
          while((c=getchar()) != EOF)
               {if(wsflg)
                    putchar(undoc(c));
               else
                    putchar(c);
               }

     if(!isstdin)          /* files */
          while(argc-- > 0)
               {if(fopen(*argv++,ibuf)==ERROR)
                    {fprintf(STDERR,"cat: can't open %s\n",*argv);
                    exit(dioflush());
                    }
               while((c=getc(ibuf)) != EOF && c != CPMEOF)
                    {if(wsflg)
                         putchar(undoc(c));
                    else
                         putchar(c);
                    }
               }

     dioflush();
}
