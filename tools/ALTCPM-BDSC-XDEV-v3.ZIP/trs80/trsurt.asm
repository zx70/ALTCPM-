;
;	INITUART.ASM
;
;Program for initiating the TRS-80 Model I UART
;(RS232C board) so that MODEM, MBOOT, MTN etc will
;work properly. You can include this in MODEM or
;MBOOT if you wish.
;



defc MRSPT	=	0E8H	;master reset port
defc BDRTPT	=	0E9H	;baud rate port
defc CTRLPT	=	0EAH	;UART control port
;
defc BD300	=	055H	;300 baud
defc CTWD	=	06DH	;8 bit word, 1 stop bit
			;no parity, set DTR
;
;The next three lines are only for information.
defc DTPT	=	0EBH	;data port
defc RCVMSK	=	080H	;receive status mask
defc TRNMSK	=	040H	;transmit status mask
;
	ORG	04300H	;start of TPA
;
	OUT	(MRSPT),a	;reset UART, doesn't matter
			;what is in A
	ld	A,BD300
	OUT	(BDRTPT),a	;set baud rate at 300
	ld	A,CTWD
	OUT	(CTRLPT),a	;set control port
	JMP	04200H	;do a warm boot
;
