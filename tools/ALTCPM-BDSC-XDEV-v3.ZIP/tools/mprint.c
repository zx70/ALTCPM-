/*
BDS C MULTIPLE FILE PRINT utility.
Created June 14, 1984.
All output through BDOS calls, for speed and compactness.
v1.1           28 Nov 1985

Compile with:
	cc mprint -e3000
	clink mprint -n -s

MPRINT features:
	command line accepts wildcard filenames
	zeroes the high bit of all input characters
	screens file(s) with or without printer output
	user options:
		printer output
		left margin indentation
		tab setting
		lines / page
		line spacing
		starting page
		page numbering
		text width
		page pause [continue / abort]
		number of copies  (6/6/85)
*/


#include <wildexp.c>


/*   Constants   */

#define CHAREOF 255	/*   CHAR represemtation of -1   */
#define LF 10
#define FF 12
#define CR 13
#define SPACE 32


/*   Global vars   */

char ibuf [BUFSIZ];
char c, kars, pagenum, ppause, printer, printing, tabb;
int copy, copies, f, fd, i, indent, width;
int line, lines, linesp, page, start, temp;


main (argc, argv)
int argc;
char **argv;
  {

    /*   Sign on   */
    nline (2);
    mesg  ("MPRINT    v1.1    28 Nov 1985    <c> Peter Brawley$");
    nline (2);
    start = 1;
    copies = 1;

    /*   Check wildcard syntax   */
    if (wildexp (&argc, &argv) == ERROR) {
      mesg ("Too many files.$");
        nline (1);
        exit ();
    }
    if (argc == 1) {
      mesg ("Usage:  MPRINT <disk:>filename.$");
      nline (1);
      mesg ("        Exclude files with <!filename>$");
      nline (1);
      mesg ("        <Filename> may include <*> and <?>$");
      nline (1);
      exit ();
    }
      
    /*   Initialise vars   */
    mesg  ("To select default settings [ ], press RETURN.$");
    nline (2);

    /*   Printer output  ?   */
    mesg ("Output to PRINTER [yes]  ?  $");
    printer = bool (TRUE);

    /*   Left margin   */
    mesg ("Left margin indentation [0]  ==>  $");
    indent = number (0);

    /*   Tab setting   */
    mesg ("Tab setting [8]  ==>  $");
    tabb = number (8);

    /*   Line spacing   */
    mesg ("Line spacing [1]  ==>  $");
    linesp = number (1) - 1;

    /*   Lines per page   */
    mesg ("Lines / page [56]  ==>  $");
    lines = number (56);

    /*   Print page numbers ?   */
    mesg ("Print page numbers [yes]  ?  $");
    pagenum = bool (TRUE);

    /*   Width ?  */
    mesg ("Text width [65]  ?  $");
    width = (number (65) / 2) + indent;
    

    /*   Page pause ?   */
    mesg ("Page pause [no]  ?  $");
    ppause = bool (FALSE);

    if (printer) {

      /*  Number of copies  */
      mesg ("Number of copies [1] ==>  $");
      copies = number (1);

      /*  Starting page  */ 
      if (argc == 2) {
        mesg ("Starting page [1] ==>  $");
        start = number (1);
      }

      nline (2);
      mesg ("HIT ANY KEY TO BEGIN ...$");
      getchar (c);
    }

    for (f = 1; f < argc; f++) {

      for (copy = 0; copy < copies; copy++) {

        if ((fd = fopen (argv [f], ibuf)) == ERROR) {
          nline (1);
          mesg ("++  Can't open file  ++$");
          exit ();
        }

	line = 0;
	kars = 0;
	page = 1;

	/*   Start with a clear screen 	 */
	bdos (2, CPMEOF);
	leftmargin ();

	/*   Read the file char by char, zero the high bit   */
    	while ((c = getc (ibuf)) != CHAREOF && c != CPMEOF) {
          /*  Strip high bit  */
          c = c & 127;
	  /*   If it's a tab, expand it   */
	  if (c == 9) repeat (SPACE, tabb-kars);
	  else print (c);
	  /*   End of line   */
	  if (c == LF) {
	    temp = linesp;
	    line++;
	    while (temp-- > 0) {
		line++;
		print (LF);
	    }
	    /*   End of page   */
	    if (line >= lines) {
		endpage (page);
		if (ppause) pause ();
		if (ppause == FALSE) nline (3);
		page++;
		line = 0;
	    } 
	    leftmargin ();
	  } 
	}
	/*   Pad last page   */
	if (line != 0) endpage (page);
        fclose (ibuf);
	if (ppause && (copy < copies || f < argc)) pause ();
      }
    }
  }


mesg (msg)
char *msg;
    {
	bdos (9, msg);
    }


print (k)
char k;
    {
	bdos (2, k);
	if (printing) bdos (5, k);
	kars ++;
	if (kars == tabb) kars = 0;
    }


repeat (k, howmany)
char k;
int howmany;
    {
	while (howmany > 0) {
	    print (k);
	    howmany --;
	}
    }


leftmargin ()
    {
	printing = (printer && page >= start);
	repeat (SPACE, indent);
	kars = 0;
    }


nline (nl)
char nl;
    {
	while (nl-- > 0) {
	    bdos (2, CR);
	    bdos (2, LF);
	}
    }


char bool (def)
char def;
    /*   Set to DEFault unless user typed <yes> or <no>   */
    {
	char b, choice;
	choice = toupper (getchar (c));
	/*   Print crlf if one wasn't typed   */
	if (choice != '\n') nline (1);
	b = def;
	if (choice == 'Y') b = TRUE;
	if (choice == 'N') b = FALSE;
	return (b);
    }


number (def)
int def;
    /*   Input a string, convert to integer value  */
    {
	int num;
	char *nbuff [10];
	getline (nbuff, 10);
	num = atoi (nbuff);
	if (num == 0) num = def;
	return (num);
    }


endpage (pg)
int pg ;
    /*   Pad the page, print page# if <pagenum> is true   */
    {
	char s [10];
	if (pagenum) {
	    print (CR);
	    while (line < (lines+3)) {
		print (LF);
		line ++;
	    }
	    i = 0;
	    while (i++ < width) print (SPACE);
	    i = 0;
	    /*   Convert integer to ASCII, print it   */
	    do {
		i ++;
		s [i] = (pg % 10) + '0';
	    } while ((pg /= 10) > 0);
	    while (i > 0) print (s [i--]);
	    print (CR);
	    print (LF);
	}
	if (printing) bdos (5, FF);
    }


pause ()
  {
    nline (1);
    mesg ("CONTINUE  ?  $");
    if (!bool (TRUE)) exit ();
    bdos (2, CPMEOF);
  }
