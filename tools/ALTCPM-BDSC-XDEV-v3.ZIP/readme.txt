
--------------------------------------------------------------
TO TEST THE ALTCPM PROGRAMS ON A REGULAR CP/M SYSTEM:
--------------------------------------------------------------

>copy /b reloc.bin+find.com test.com


--------------------------------------------------------------
Examples of complex build sessions:
--------------------------------------------------------------

>cpm.exe cc.cpm cat.c
BD Software C Compiler v1.45T (part I)
  29K elbowroom
Can't find CC2.COM; writing CCI file to disk

>cpm.exe c2.cpm cat.c
BD Software C Compiler v1.45 (part II)
  25K to spare


>cpm.exe l2.cpm cat
Mark of the Unicorn Linker ver. 2.2.2
Loading  CAT.CRL
LINK MAIN     -> 499E
Scanning DEFF.CRL
LINK FOPEN    -> 4A9C
LINK FPRINTF  -> 4ADC
LINK GETC     -> 4B0A
LINK _SPR     -> 4BD6
LINK FPUTS    -> 4F36
LINK _USPR    -> 4F9A
LINK ISDIGIT  -> 503C
LINK _GV2     -> 506B
LINK TOUPPER  -> 50C8
LINK PUTC     -> 50FC
LINK ISLOWER  -> 5224
Scanning DEFF2.CRL
LINK GETCHAR  -> 5253
LINK PUTCHAR  -> 5288
LINK OPEN     -> 52B7
LINK BDOS     -> 52FB
LINK READ     -> 530E
LINK WRITE    -> 5384
*** Missing functions:
DIOINIT
DIOFLUSH
Enter the name of a file to be searched or CR: dio.crl

Scanning DIO.CRL
LINK DIOINIT  -> 53EC
LINK DIOFLUSH -> 5782
*** Missing functions:
EXIT
STRCMP
UNLINK
FCREAT
FCLOSE
FFLUSH
RENAME
EXECV
Enter the name of a file to be searched or CR: deff.crl

Scanning DEFF.CRL
LINK STRCMP   -> 5886
LINK FCREAT   -> 5915
LINK FCLOSE   -> 5967
LINK FFLUSH   -> 5990
*** Missing functions:
EXIT
UNLINK
RENAME
EXECV
CREAT
CLOSE
MOVMEM
SEEK
Enter the name of a file to be searched or CR: deff2.crl

Scanning DEFF2.CRL
LINK EXIT     -> 5ACF
LINK UNLINK   -> 5AD2
LINK RENAME   -> 5AE7
LINK EXECV    -> 5B46
LINK CREAT    -> 5B7C
LINK CLOSE    -> 5BA4
LINK MOVMEM   -> 5BA7
LINK SEEK     -> 5BF8
LINK EXECL    -> 5C5D
LINK TELL     -> 5D42


Link statistics:
  Number of functions: 34
  Code ends at: 0x5D68
  Externals begin at: 0x5D68
  Externals end at: 0x657D
  End of current L2 TPA: 0xFE06
  Jump table bytes saved: 0xC3
  Link space remaining: 30K

-------------------------------------------------------------

>cpm.exe  cc.cpm find.c
BD Software C Compiler v1.45T (part I)
  27K elbowroom
Can't find CC2.COM; writing CCI file to disk

>cpm.exe  c2.cpm find.c
BD Software C Compiler v1.45 (part II)
  23K to spare

>cpm.exe  l2.cpm find
Mark of the Unicorn Linker ver. 2.2.2
Loading  FIND.CRL
LINK MAIN     -> 499E
LINK GMATCH   -> 4CEF
LINK MATCH    -> 4D86
LINK STOUPPER -> 4DFE
Scanning DEFF.CRL
LINK STRCPY   -> 4E35
LINK FGETS    -> 4E7D
LINK PRINTF   -> 4F71
LINK TOUPPER  -> 4F96
LINK GETC     -> 4FCA
LINK UNGETC   -> 5096
LINK _SPR     -> 5104
LINK PUTS     -> 5464
LINK ISLOWER  -> 5490
LINK _USPR    -> 54BF
LINK ISDIGIT  -> 5561
LINK _GV2     -> 5590
Scanning DEFF2.CRL
LINK GETCHAR  -> 55ED
LINK BDOS     -> 5622
LINK READ     -> 5635
LINK UNGETCH  -> 56AB
LINK PUTCHAR  -> 56BA
*** Missing functions:
DIOINIT
ERROR
RCARG
GETPAT
DIOFLUSH
AMATCH
Enter the name of a file to be searched or CR: dio.crl

Scanning DIO.CRL
LINK DIOINIT  -> 56E9
LINK DIOFLUSH -> 5A7F
*** Missing functions:
ERROR
RCARG
GETPAT
AMATCH
FOPEN
FPRINTF
EXIT
STRCMP
UNLINK
FCREAT
FCLOSE
PUTC
FFLUSH
RENAME
EXECV
Enter the name of a file to be searched or CR: deff.crl

Scanning DEFF.CRL
LINK FOPEN    -> 5B83
LINK FPRINTF  -> 5BC3
LINK STRCMP   -> 5BF1
LINK FCREAT   -> 5C80
LINK FCLOSE   -> 5CD2
LINK PUTC     -> 5CFB
LINK FFLUSH   -> 5E23
LINK FPUTS    -> 5F62
*** Missing functions:
ERROR
RCARG
GETPAT
AMATCH
EXIT
UNLINK
RENAME
EXECV
OPEN
CREAT
CLOSE
WRITE
MOVMEM
SEEK
Enter the name of a file to be searched or CR: deff2.crl

Scanning DEFF2.CRL
LINK EXIT     -> 5FC6
LINK UNLINK   -> 5FC9
LINK RENAME   -> 5FDE
LINK EXECV    -> 603D
LINK OPEN     -> 6073
LINK CREAT    -> 60B7
LINK CLOSE    -> 60DF
LINK WRITE    -> 60E2
LINK MOVMEM   -> 614A
LINK SEEK     -> 619B
LINK EXECL    -> 6200
LINK TELL     -> 62E5
*** Missing functions:
ERROR
RCARG
GETPAT
AMATCH
Enter the name of a file to be searched or CR: mylib3.crl

Scanning MYLIB3.CRL
LINK ERROR    -> 630B
LINK RCARG    -> 633A
LINK GETPAT   -> 63D3
LINK AMATCH   -> 63FD
LINK MAKEPAT  -> 65B6
LINK PATSIZE  -> 6884
LINK OMATCH   -> 690C
LINK ADDSTR   -> 6AEE
LINK GETCCL   -> 6B40
LINK STCLOSE  -> 6C45
LINK ESC      -> 6CD6
LINK LOCATE   -> 6EF3
LINK DODASH   -> 6F6A
LINK ISALPNUM -> 71A0
*** Missing functions:
TOLOWER
Enter the name of a file to be searched or CR: deff.crl

Scanning DEFF.CRL
LINK TOLOWER  -> 721E
LINK ISUPPER  -> 7252


Link statistics:
  Number of functions: 59
  Code ends at: 0x7281
  Externals begin at: 0x7281
  Externals end at: 0x7A96
  End of current L2 TPA: 0xFE06
  Jump table bytes saved: 0x15F
  Link space remaining: 25K

